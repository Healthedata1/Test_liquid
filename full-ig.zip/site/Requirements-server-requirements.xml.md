# Server Requirements - XML Representation - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Server Requirements**

## : Server Requirements - XML Representation

| | |
| :--- | :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 |

[Raw xml](Requirements-server-requirements.xml) | [Download](Requirements-server-requirements.xml)

