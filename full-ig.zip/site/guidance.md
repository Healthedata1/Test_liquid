# Guidance - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Guidance**

## Guidance

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

### Intro

sed dui ante. Nunc eget dapibus augue. Etiam feugiat consectetur odio sed rhoncus. Mauris vel malesuada nunc. Fusce consequat nisl non nulla venenatis, quis vehicula nunc congue. Duis laoreet ex sapien, at dictum justo vehicula vitae. Suspendisse ac dui et nunc sollicitudin tincidunt.

Curabitur rutrum mi nec lectus tristique efficitur. Vivamus vel commodo orci, quis fringilla tortor. Suspendisse eget velit tincidunt, rutrum arcu ut, placerat augue. Vestibulum lorem sapien, pharetra nec vulputate ut, feugiat in urna. Suspendisse feugiat ullamcorper nunc nec sagittis. Phasellus vitae purus quam. Integer vitae enim eu neque lacinia viverra. Curabitur feugiat lorem ac augue hendrerit consectetur. Nulla ornare magna eu sem rutrum egestas.

Donec auctor bibendum est, non vehicula dui accumsan vel. Integer pretium lacus ut vulputate auctor. Curabitur eget odio lacus. Praesent iaculis sem id elit porta mollis. Suspendisse a neque risus. Ut condimentum varius scelerisque. Fusce tristique velit sed blandit ornare. Vivamus consectetur lectus ipsum. In quis sollicitudin mauris. In sodales quam ut dolor dictum, quis convallis risus feugiat. Cras auctor tellus et lacus blandit, sed cursus nisi tristique. Vestibulum tincidunt consectetur eros ac bibendum. Aenean quis mauris in lectus iaculis aliquet sed non tortor. Donec in tempor lorem. Nulla blandit luctus dictum. Integer pharetra sapien nulla.

Praesent cursus ultricies massa, in pretium dui sagittis vel. Phasellus laoreet porta diam. Sed dictum elementum metus, ut sollicitudin augue pulvinar ac. Pellentesque vitae quam sem. Aenean et lectus euismod, fermentum diam vitae, vestibulum velit. Proin gravida faucibus tellus. Suspendisse potenti. Donec id augue vel dolor laoreet viverra. Mauris venenatis ultricies augue. Fusce accumsan felis ac dui pellentesque blandit. Quisque a tellus sed orci mattis sodales. Morbi vitae diam lectus. In non vestibulum velit. Proin placerat nulla non bibendum convallis. Nulla venenatis, velit a auctor consectetur, velit odio malesuada augue, ut rhoncus libero magna non nisi.

Sed eu arcu a leo feugiat dapibus eget euismod nunc. Suspendisse pulvinar magna vitae blandit facilisis. In tristique metus sed enim fermentum, at molestie diam posuere. Pellentesque varius lorem eget tellus vulputate porta. Maecenas nec iaculis purus, rhoncus molestie metus. Aliquam at efficitur turpis. Morbi sodales sapien nec ligula sodales blandit. Aliquam erat volutpat. Fusce gravida imperdiet pulvinar. Vestibulum nec leo sit amet lorem facilisis volutpat. Suspendisse ut ante fermentum magna molestie porttitor nec ut libero

### Foo

sed dui ante. Nunc eget dapibus augue. Etiam feugiat consectetur odio sed rhoncus. Mauris vel malesuada nunc. Fusce consequat nisl non nulla venenatis, quis vehicula nunc congue. Duis laoreet ex sapien, at dictum justo vehicula vitae. Suspendisse ac dui et nunc sollicitudin tincidunt.

Curabitur rutrum mi nec lectus tristique efficitur. Vivamus vel commodo orci, quis fringilla tortor. Suspendisse eget velit tincidunt, rutrum arcu ut, placerat augue. Vestibulum lorem sapien, pharetra nec vulputate ut, feugiat in urna. Suspendisse feugiat ullamcorper nunc nec sagittis. Phasellus vitae purus quam. Integer vitae enim eu neque lacinia viverra. Curabitur feugiat lorem ac augue hendrerit consectetur. Nulla ornare magna eu sem rutrum egestas.

Donec auctor bibendum est, non vehicula dui accumsan vel. Integer pretium lacus ut vulputate auctor. Curabitur eget odio lacus. Praesent iaculis sem id elit porta mollis. Suspendisse a neque risus. Ut condimentum varius scelerisque. Fusce tristique velit sed blandit ornare. Vivamus consectetur lectus ipsum. In quis sollicitudin mauris. In sodales quam ut dolor dictum, quis convallis risus feugiat. Cras auctor tellus et lacus blandit, sed cursus nisi tristique. Vestibulum tincidunt consectetur eros ac bibendum. Aenean quis mauris in lectus iaculis aliquet sed non tortor. Donec in tempor lorem. Nulla blandit luctus dictum. Integer pharetra sapien nulla.

Praesent cursus ultricies massa, in pretium dui sagittis vel. Phasellus laoreet porta diam. Sed dictum elementum metus, ut sollicitudin augue pulvinar ac. Pellentesque vitae quam sem. Aenean et lectus euismod, fermentum diam vitae, vestibulum velit. Proin gravida faucibus tellus. Suspendisse potenti. Donec id augue vel dolor laoreet viverra. Mauris venenatis ultricies augue. Fusce accumsan felis ac dui pellentesque blandit. Quisque a tellus sed orci mattis sodales. Morbi vitae diam lectus. In non vestibulum velit. Proin placerat nulla non bibendum convallis. Nulla venenatis, velit a auctor consectetur, velit odio malesuada augue, ut rhoncus libero magna non nisi.

Sed eu arcu a leo feugiat dapibus eget euismod nunc. Suspendisse pulvinar magna vitae blandit facilisis. In tristique metus sed enim fermentum, at molestie diam posuere. Pellentesque varius lorem eget tellus vulputate porta. Maecenas nec iaculis purus, rhoncus molestie metus. Aliquam at efficitur turpis. Morbi sodales sapien nec ligula sodales blandit. Aliquam erat volutpat. Fusce gravida imperdiet pulvinar. Vestibulum nec leo sit amet lorem facilisis volutpat. Suspendisse ut ante fermentum magna molestie porttitor nec ut libe

### Bar

sed dui ante. Nunc eget dapibus augue. Etiam feugiat consectetur odio sed rhoncus. Mauris vel malesuada nunc. Fusce consequat nisl non nulla venenatis, quis vehicula nunc congue. Duis laoreet ex sapien, at dictum justo vehicula vitae. Suspendisse ac dui et nunc sollicitudin tincidunt.

Curabitur rutrum mi nec lectus tristique efficitur. Vivamus vel commodo orci, quis fringilla tortor. Suspendisse eget velit tincidunt, rutrum arcu ut, placerat augue. Vestibulum lorem sapien, pharetra nec vulputate ut, feugiat in urna. Suspendisse feugiat ullamcorper nunc nec sagittis. Phasellus vitae purus quam. Integer vitae enim eu neque lacinia viverra. Curabitur feugiat lorem ac augue hendrerit consectetur. Nulla ornare magna eu sem rutrum egestas.

Donec auctor bibendum est, non vehicula dui accumsan vel. Integer pretium lacus ut vulputate auctor. Curabitur eget odio lacus. Praesent iaculis sem id elit porta mollis. Suspendisse a neque risus. Ut condimentum varius scelerisque. Fusce tristique velit sed blandit ornare. Vivamus consectetur lectus ipsum. In quis sollicitudin mauris. In sodales quam ut dolor dictum, quis convallis risus feugiat. Cras auctor tellus et lacus blandit, sed cursus nisi tristique. Vestibulum tincidunt consectetur eros ac bibendum. Aenean quis mauris in lectus iaculis aliquet sed non tortor. Donec in tempor lorem. Nulla blandit luctus dictum. Integer pharetra sapien nulla.

Praesent cursus ultricies massa, in pretium dui sagittis vel. Phasellus laoreet porta diam. Sed dictum elementum metus, ut sollicitudin augue pulvinar ac. Pellentesque vitae quam sem. Aenean et lectus euismod, fermentum diam vitae, vestibulum velit. Proin gravida faucibus tellus. Suspendisse potenti. Donec id augue vel dolor laoreet viverra. Mauris venenatis ultricies augue. Fusce accumsan felis ac dui pellentesque blandit. Quisque a tellus sed orci mattis sodales. Morbi vitae diam lectus. In non vestibulum velit. Proin placerat nulla non bibendum convallis. Nulla venenatis, velit a auctor consectetur, velit odio malesuada augue, ut rhoncus libero magna non nisi.

Sed eu arcu a leo feugiat dapibus eget euismod nunc. Suspendisse pulvinar magna vitae blandit facilisis. In tristique metus sed enim fermentum, at molestie diam posuere. Pellentesque varius lorem eget tellus vulputate porta. Maecenas nec iaculis purus, rhoncus molestie metus. Aliquam at efficitur turpis. Morbi sodales sapien nec ligula sodales blandit. Aliquam erat volutpat. Fusce gravida imperdiet pulvinar. Vestibulum nec leo sit amet lorem facilisis volutpat. Suspendisse ut ante fermentum magna molestie porttitor nec ut liberoro

### Guidance

sed dui ante. Nunc eget dapibus augue. Etiam feugiat consectetur odio sed rhoncus. Mauris vel malesuada nunc. Fusce consequat nisl non nulla venenatis, quis vehicula nunc congue. Duis laoreet ex sapien, at dictum justo vehicula vitae. Suspendisse ac dui et nunc sollicitudin tincidunt.

Curabitur rutrum mi nec lectus tristique efficitur. Vivamus vel commodo orci, quis fringilla tortor. Suspendisse eget velit tincidunt, rutrum arcu ut, placerat augue. Vestibulum lorem sapien, pharetra nec vulputate ut, feugiat in urna. Suspendisse feugiat ullamcorper nunc nec sagittis. Phasellus vitae purus quam. Integer vitae enim eu neque lacinia viverra. Curabitur feugiat lorem ac augue hendrerit consectetur. Nulla ornare magna eu sem rutrum egestas.

Donec auctor bibendum est, non vehicula dui accumsan vel. Integer pretium lacus ut vulputate auctor. Curabitur eget odio lacus. Praesent iaculis sem id elit porta mollis. Suspendisse a neque risus. Ut condimentum varius scelerisque. Fusce tristique velit sed blandit ornare. Vivamus consectetur lectus ipsum. In quis sollicitudin mauris. In sodales quam ut dolor dictum, quis convallis risus feugiat. Cras auctor tellus et lacus blandit, sed cursus nisi tristique. Vestibulum tincidunt consectetur eros ac bibendum. Aenean quis mauris in lectus iaculis aliquet sed non tortor. Donec in tempor lorem. Nulla blandit luctus dictum. Integer pharetra sapien nulla.

Praesent cursus ultricies massa, in pretium dui sagittis vel. Phasellus laoreet porta diam. Sed dictum elementum metus, ut sollicitudin augue pulvinar ac. Pellentesque vitae quam sem. Aenean et lectus euismod, fermentum diam vitae, vestibulum velit. Proin gravida faucibus tellus. Suspendisse potenti. Donec id augue vel dolor laoreet viverra. Mauris venenatis ultricies augue. Fusce accumsan felis ac dui pellentesque blandit. Quisque a tellus sed orci mattis sodales. Morbi vitae diam lectus. In non vestibulum velit. Proin placerat nulla non bibendum convallis. Nulla venenatis, velit a auctor consectetur, velit odio malesuada augue, ut rhoncus libero magna non nisi.

Sed eu arcu a leo feugiat dapibus eget euismod nunc. Suspendisse pulvinar magna vitae blandit facilisis. In tristique metus sed enim fermentum, at molestie diam posuere. Pellentesque varius lorem eget tellus vulputate porta. Maecenas nec iaculis purus, rhoncus molestie metus. Aliquam at efficitur turpis. Morbi sodales sapien nec ligula sodales blandit. Aliquam erat volutpat. Fusce gravida imperdiet pulvinar. Vestibulum nec leo sit amet lorem facilisis volutpat. Suspendisse ut ante fermentum magna molestie porttitor nec ut libero.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. [**SHALL**][CONF-0175] Aliquam tortor erat, semper tristique lorem quis, consequat convallis massa. In tincidunt massa in sagittis viverra. Mauris vitae ultricies sapien. Nunc volutpat odio eget dolor malesuada, a feugiat felis ultrices. Phasellus tempor ultrices nisl, nec blandit velit ornare quis. Cras est arcu, placerat in turpis nec, pulvinar molestie mauris. Phasellus at neque nunc. Morbi tincidunt varius bibendum.

Donec scelerisque odio a lectus iaculis semper. Morbi scelerisque sem ac nunc euismod, in luctus leo pellentesque. Sed fermentum luctus diam, eget hendrerit odio pharetra in. Nullam feugiat imperdiet libero, et condimentum est. Morbi vel tempus erat. Donec ex nisl, maximus sed augue eu, [**SHOULD**][CONF-0176] hendrerit imperdiet sem. Sed quis porttitor tortor. Integer maximus vitae dolor quis ultrices. Aliquam elementum quam nulla. Sed ac consequat nisi, eget dapibus arcu. Aenean sit amet ligula ac arcu blandit porttitor.

Cras dignissim eleifend augue, in aliquam nisl mollis et. Nulla facilisi. Nunc leo velit, gravida quis justo ut, elementum lacinia magna. Nunc orci tellus, tincidunt egestas malesuada in, egestas feugiat sem. Curabitur ultrices lorem mi, vitae sagittis erat cursus vitae. Vivamus vitae metus scelerisque, cursus nulla nec, ultrices elit. Proin finibus, mauris vitae vulputate molestie, sapien turpis blandit nunc, id tincidunt justo dolor a ante. [**SHALL**][CONF-0177] liquam egestas libero sed orci rutrum eleifend.

[**MAY**][CONF-0178] [**SHOULD**][CONF-0179] [**SHALL**][CONF-0174]

