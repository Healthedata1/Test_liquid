# Home - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/healthedata1-sandbox/ImplementationGuide/hl7.fhir.us.healthedata1-sandbox | *Version*:0.1.0 | |
| * IG Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:HealtheData_1Sandbox |

### Health eData Sandbox

testbed for ideas….

#### FOO

using http:

[US Core](http://hl7.org/fhir/us/core)

[FHIR](http://hl7.org/fhir/)

using https:

[US Core](https://hl7.org/fhir/us/core/STU4/index.html)

[FHIR](https://hl7.org/fhir/)

using path variable

[FHIR](http://hl7.org/fhir/R4/)

#### in list…:

using http:

* [US Core](http://hl7.org/fhir/us/core)
* [FHIR](http://hl7.org/fhir/)

using https:

* [US Core](https://hl7.org/fhir/us/core/STU4/index.html)
* [FHIR](https://hl7.org/fhir/)

#### in table…:

using http:

| |
| :--- |
| [US Core](http://hl7.org/fhir/us/core) |
| [FHIR](http://hl7.org/fhir/) |

using https:

| |
| :--- |
| [US Core](https://hl7.org/fhir/us/core/STU4/index.html) |
| [FHIR](https://hl7.org/fhir/) |

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.us.healthedata1-sandbox.r4)](package.r4.tgz) and [R4B (hl7.fhir.us.healthedata1-sandbox.r4b)](package.r4b.tgz) are available.

bar This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.us.healthedata1-sandbox.r4)](package.r4.tgz) and [R4B (hl7.fhir.us.healthedata1-sandbox.r4b)](package.r4b.tgz) are available.  foo

### IG Dependencies

This IG Contains the following dependencies on other IGs.








### Global Profiles

*There are no Global profiles defined*

### Copyrights

```
This publication includes IP covered under the following statements.
<ul>
<li>ISO Maintains the copyright on the country codes, and controls it's use carefully. For futher details see the ISO 3166 web page: <a href="https://www.iso.org/iso-3166-country-codes.html">https://www.iso.org/iso-3166-country-codes.html</a><div data-fhir="generated" id="ipp_1" onClick="if (document.getElementById('ipp2_1').innerHTML != '') {document.getElementById('ipp_1').innerHTML = document.getElementById('ipp2_1').innerHTML; document.getElementById('ipp2_1').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_1" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/5.0.0/CodeSystem-ISO3166Part1.html">ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code</a>: <a href="Basic-example-requirements-backport.html">Basic/example-requirements-backport</a>, <a href="Requirements-client-requirements.html">ClientRequirements</a><span id="ips_1" onClick="document.getElementById('ips_1').innerHTML = document.getElementById('ips2_1').innerHTML">... <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show 4 more</span></span><span id="ips2_1" style="display: none">, <a href="Requirements-example-requirements.html">ExampleRequirements</a>, <a href="index.html">HealtheData_1Sandbox</a>, <a href="ValueSet-proc_codes.html">ProcedureCodes</a> and <a href="Requirements-us-core-server.html">USCoreServerRequirements</a></span></li>
</ul>
</div></li>
<li>Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission.For information and exceptions regarding use of CDC material please see <a href="https://www.cdc.gov/other/agencymaterials.html">https://www.cdc.gov/other/agencymaterials.html</a>.<div data-fhir="generated" id="ipp_2" onClick="if (document.getElementById('ipp2_2').innerHTML != '') {document.getElementById('ipp_2').innerHTML = document.getElementById('ipp2_2').innerHTML; document.getElementById('ipp2_2').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_2" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/5.0.0/CodeSystem-CDCREC.html">CDC Race and Ethnicity</a>: <a href="Patient-deceased-example.html">Patient/deceased-example</a></li>
</ul>
</div></li>
<li>This material contains content from <a href="http://loinc.org">LOINC</a>. LOINC is copyright &copy; 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the <a href="http://loinc.org/license">license</a>. LOINC&reg; is a registered United States trademark of Regenstrief Institute, Inc.<div data-fhir="generated" id="ipp_3" onClick="if (document.getElementById('ipp2_3').innerHTML != '') {document.getElementById('ipp_3').innerHTML = document.getElementById('ipp2_3').innerHTML; document.getElementById('ipp2_3').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_3" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/5.0.0/CodeSystem-v3-loinc.html">LOINC</a>: <a href="ValueSet-proc_codes.html">ProcedureCodes</a></li>
</ul>
</div></li>
<li>This material derives from the HL7 Terminology (THO). THO is copyright &copy;1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: <a href="https://terminology.hl7.org/license.html">https://terminology.hl7.org/license.html</a><div data-fhir="generated" id="ipp_4" onClick="if (document.getElementById('ipp2_4').innerHTML != '') {document.getElementById('ipp_4').innerHTML = document.getElementById('ipp2_4').innerHTML; document.getElementById('ipp2_4').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_4" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html">identifierType</a>: <a href="Patient-deceased-example.html">Patient/deceased-example</a></li>
</ul>
</div></li>
</ul>
<!--$$1$$-->

```

This publication includes IP covered under the following statements.

* ISO Maintains the copyright on the country codes, and controls it's use carefully. For futher details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/5.0.0/CodeSystem-ISO3166Part1.html): [Basic/example-requirements-backport](Basic-example-requirements-backport.md), [ClientRequirements](Requirements-client-requirements.md)... Show 4 more, [ExampleRequirements](Requirements-example-requirements.md), [HealtheData_1Sandbox](index.md), [ProcedureCodes](ValueSet-proc_codes.md) and [USCoreServerRequirements](Requirements-us-core-server.md)


* Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission.For information and exceptions regarding use of CDC material please see [https://www.cdc.gov/other/agencymaterials.html](https://www.cdc.gov/other/agencymaterials.html).

* [CDC Race and Ethnicity](http://terminology.hl7.org/5.0.0/CodeSystem-CDCREC.html): [Patient/deceased-example](Patient-deceased-example.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/5.0.0/CodeSystem-v3-loinc.html): [ProcedureCodes](ValueSet-proc_codes.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Patient/deceased-example](Patient-deceased-example.md)


### using {{site.data.resources[resource_].description}}

by string

{{site.data.resources['ImplementationGuide/healthedata1-sandbox'].description | markdownify}}

with markdown filter

without markdown filter

0: John

1: Paul

2: George

3: Ringo

