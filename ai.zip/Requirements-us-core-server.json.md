# US Core Server Requirements - JSON Representation - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **US Core Server Requirements**

## : US Core Server Requirements - JSON Representation

| | |
| :--- | :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 |

[Raw json](Requirements-us-core-server.json) | [Download](Requirements-us-core-server.json)

